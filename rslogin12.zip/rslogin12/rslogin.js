
chrome.extension.onMessage.addListener(function (req, sender, sendResponse) {
	var request;
	if(req.indexOf("&souei&") != -1){
		request = req.split("&souei&");
		if(request[0]=="mkBox"){
			var body = document.querySelector('body');
			if(document.getElementById('rslogin')){
				document.getElementById('rslogin').remove();
				document.getElementById('rsloginjs').remove();
			};
			var box = document.createElement('table');
			box.id="rslogin";
			box.style="display: block;position: absolute;background-color: #f9f9f9;border: 1px solid #ccc;z-index: 1000;left:35vw;";
			box.border="1";
			var naiyou='<tr><th style="width:15vw">ID</th><th style="width:15vw">PASS</th></tr>';
			naiyou=naiyou+'<tr><td id="id">'+request[1]+'</td><td id="pass">'+request[2]+'</td></tr>';
			naiyou=naiyou+'<tr><td colspan="2"><input type="button" value="閉じる" id="close" style="width:30vw"></td></tr>';
			box.innerHTML=naiyou;
			body.prepend(box);
			var code = document.createElement('script');
			code.id='rsloginjs';
			naiyou='document.getElementById("close").addEventListener("click", (e) => {';
			naiyou=naiyou+'f1();';
			naiyou=naiyou+'});';
			naiyou=naiyou+'document.getElementById("id").addEventListener("click", (e) => {';
			naiyou=naiyou+'navigator.clipboard.writeText(document.getElementById("id").textContent);';
			naiyou=naiyou+'});';
			naiyou=naiyou+'document.getElementById("pass").addEventListener("click", (e) => {';
			naiyou=naiyou+'navigator.clipboard.writeText(document.getElementById("pass").textContent);';
			naiyou=naiyou+'});';
			naiyou=naiyou+'function f1(){';
			naiyou=naiyou+'document.getElementById("rslogin").remove();';
			naiyou=naiyou+'document.getElementById("rsloginjs").remove();';
			naiyou=naiyou+'};';
			naiyou=naiyou+'window.addEventListener("scroll",(e) => {';
			naiyou=naiyou+'f3();';
			naiyou=naiyou+'});';
			naiyou=naiyou+'function f3(){';
			naiyou=naiyou+'var y=window.pageYOffset;';
			naiyou=naiyou+'document.getElementById("rslogin").style="display: block;position: absolute;background-color: #f9f9f9;border: 1px solid #ccc;z-index: 1000;left:35vw;top:"+String(y)+"px;";';
			naiyou=naiyou+'};';
			code.innerHTML=naiyou;
			body.prepend(code);
		};
	}else{
		request = req;
		window.location.href = request;
    };
});




