
//初回起動時に変数を作る
chrome.storage.sync.get(["firstopen"], function(items) {
	if(items.firstopen == null){
		alert("RS LOGINのインストールが完了しました。\n※自己責任でご利用ください。作者はすべての事象において，責任を負いません。");
		chrome.storage.sync.set(
			{
				"firstopen": "1",
				"IDs": ""
			}
		);
	}    
});

